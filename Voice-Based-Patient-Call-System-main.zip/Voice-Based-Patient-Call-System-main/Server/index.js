
console.log(`Hello Node.js v${process.versions.node}!`);
